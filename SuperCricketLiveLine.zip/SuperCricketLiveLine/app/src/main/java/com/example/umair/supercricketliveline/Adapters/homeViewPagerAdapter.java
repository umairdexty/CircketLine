package com.example.umair.supercricketliveline.Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.umair.supercricketliveline.OngoingFragment;
import com.example.umair.supercricketliveline.UpcomingFragment;

public class homeViewPagerAdapter extends FragmentPagerAdapter {

    private String tabTitlesHome[] = new String[] { "ONGOING", "UPCOMING" };
    public homeViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int i) {
        if (i==0){
            return new OngoingFragment();
        }
        else if (i == 1){
            return new UpcomingFragment();
        }
        else {
            return null;
        }
    }

    @Override
    public int getCount() {
        return 2;
    }
    @Override
    public CharSequence getPageTitle(int position) {


        return tabTitlesHome[position];
    }
}
