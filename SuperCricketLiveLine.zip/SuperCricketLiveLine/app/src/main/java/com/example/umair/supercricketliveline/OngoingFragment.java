package com.example.umair.supercricketliveline;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import com.example.umair.supercricketliveline.Adapters.MatchesAdapter;
import com.example.umair.supercricketliveline.POJOClasses.MatchDetails;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class OngoingFragment extends Fragment implements MatchesAdapter.MyCLickListener {
    private RecyclerView mRecyclerView;
    private MatchesAdapter mAdapter;
    List<MatchDetails> matchesList;
    private ProgressBar progressBar;
    private String matchId;
    private Map<String,Integer> map;
    private ConstraintLayout cl;
    private View view;
    public OngoingFragment() {
        // Required empty public constructor
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {

        this.view=view;
        progressBar = view.findViewById(R.id.progressBar_onGoing);
        cl = view.findViewById(R.id.no_internet_onGoing);
        map = new HashMap<>();
        progressBar.setVisibility(View.VISIBLE);
        cl.setVisibility(View.GONE);
        new NetworkCheck().execute();
    }
    private void internetIsAvailable(boolean b){
        if (b) {
            mRecyclerView = view.findViewById(R.id.match_card_recycler_view_onGoing);
            FirebaseDatabase mFBDatabase = FirebaseDatabase.getInstance();
            matchesList = new ArrayList<>();
            mAdapter = new MatchesAdapter(matchesList, this);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getContext());
            mRecyclerView.setLayoutManager(mLayoutManager);
            mRecyclerView.setItemAnimator(new DefaultItemAnimator());
            mRecyclerView.setAdapter(mAdapter);
            mFBDatabase.getReference("match").
                    addChildEventListener(new ChildEventListener() {
                        @Override
                        public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            final MatchDetails match = dataSnapshot.getValue(MatchDetails.class);
                            match.setMatchPudhId(dataSnapshot.getKey());

                            progressBar.setVisibility(View.GONE);
                            if (match.getMatch_status().equals("Live")) {

                                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("totalscore/" + match.getMatchPudhId());

                                matchId = match.getMatchPudhId();
                                ref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dSnapshot) {
                                        for (DataSnapshot ds : dSnapshot.getChildren()) {
                                            if (ds.getKey().equals(match.getTeamA())) {
                                                String s = ds.child("score").getValue(Long.class).toString() + "-"
                                                        + ds.child("wickets").getValue(Long.class).toString() + "("
                                                        + ds.child("overs").getValue().toString() + ")";
                                                Log.e("TAG!", s);

                                                match.setFirstTeamScore(s);

                                            } else {
                                                if (ds.getKey().equals(match.getTeamB())) {
                                                    String s = ds.child("score").getValue(Long.class).toString() + "-"
                                                            + ds.child("wickets").getValue(Long.class).toString() + "("
                                                            + ds.child("overs").getValue().toString() + ")";
                                                    match.setSecondTeamScore(s);
                                                    progressBar.setVisibility(View.GONE);
                                                    Log.e("TAN!", s);
                                                }
                                            }



                                        }int index;
                                        try {
                                            index = map.get(String.valueOf(matchId));
                                        }catch (NullPointerException e){
                                            matchesList.add(match);
                                            map.put(matchId,matchesList.indexOf(match));
                                            mAdapter.notifyDataSetChanged();
                                            mRecyclerView.invalidate();
                                            return;
                                        }
                                        matchesList.set(index,match);
                                        mAdapter.notifyDataSetChanged();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                    }
                                });

                            } else {
                                matchesList.add(match);
                                map.put(dataSnapshot.getKey(),matchesList.indexOf(match));
                                mAdapter.notifyDataSetChanged();
                                mRecyclerView.invalidate();
                            }


                        }

                        @Override
                        public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                            MatchDetails match = dataSnapshot.getValue(MatchDetails.class);
                            match.setMatchPudhId(dataSnapshot.getKey());
                            int index;
                            try {
                                index = map.get(dataSnapshot.getKey());
                            }catch (NullPointerException e){
                                matchesList.add(match);
                                map.put(dataSnapshot.getKey(),matchesList.indexOf(match));
                                mAdapter.notifyDataSetChanged();
                                return;
                            }
                            matchesList.set(index,match);
                            mAdapter.notifyDataSetChanged();

                        }

                        @Override
                        public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                        }

                        @Override
                        public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
        }else {
            progressBar.setVisibility(View.GONE);
            cl.setVisibility(View.VISIBLE);
            view.findViewById(R.id.button_refresh_onGoing).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    progressBar.setVisibility(View.VISIBLE);
                    cl.setVisibility(View.GONE);
                    new NetworkCheck().execute();
                }
            });
        }

    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment OngoingFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static OngoingFragment newInstance(String param1, String param2) {
        OngoingFragment fragment = new OngoingFragment();
        Bundle args = new Bundle();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ongoing, container, false);
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {

    }


    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void Onclick(MatchDetails match) {
        Intent intent = new Intent(
                getContext(),
                ContainerActivity.class);
        intent.putExtra("MatchPushId", match.getMatch_id());
        intent.putExtra("FirstTeam", match.getTeamA());
        intent.putExtra("SecondTeam", match.getTeamB());
        intent.putExtra("MatchType", match.getMatch_type());
        startActivity(intent);
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */

    public class NetworkCheck extends AsyncTask<Void, Void, Boolean> {

        @Override
        protected Boolean doInBackground(Void... voids) {

            try {
                int timeoutMs = 1500;
                Socket sock = new Socket();
                SocketAddress sockaddr = new InetSocketAddress("8.8.8.8", 53);

                sock.connect(sockaddr, timeoutMs);
                sock.close();

                return true;
            } catch (IOException e) {
                return false;
            }
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);
            internetIsAvailable(aBoolean);
        }

    }
}
