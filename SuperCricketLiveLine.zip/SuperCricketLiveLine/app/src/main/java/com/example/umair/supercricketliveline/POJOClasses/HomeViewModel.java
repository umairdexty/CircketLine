package com.example.umair.supercricketliveline.POJOClasses;

import android.app.Application;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomeViewModel extends AndroidViewModel {

    private String matchId;
    MutableLiveData<List<MatchDetails>> _ongoing_matchesList = new MutableLiveData<>();
    MutableLiveData<List<MatchDetails>> _upcoming_matchesList = new MutableLiveData<>();
    final private List<MatchDetails> _ongoing_temp = new ArrayList<>();
    final private List<MatchDetails> _upcoming_temp = new ArrayList<>();

    public HomeViewModel(@NonNull Application application) {
        super(application);
        FirebaseDatabase mFBDatabase = FirebaseDatabase.getInstance();


        mFBDatabase.getReference("match").
                addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@android.support.annotation.NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        final MatchDetails match = dataSnapshot.getValue(MatchDetails.class);
                        match.setMatchPudhId(dataSnapshot.getKey());


                        if (match.getMatch_status().equals("Live")) {

                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference("totalscore/" + match.getMatchPudhId());

                            matchId = match.getMatchPudhId();
                            ref.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@android.support.annotation.NonNull DataSnapshot dSnapshot) {
                                    for (DataSnapshot ds : dSnapshot.getChildren()) {
                                        if (ds.getKey().equals(match.getTeamA())) {
                                            String s = ds.child("score").getValue(Long.class).toString() + "-"
                                                    + ds.child("wickets").getValue(Long.class).toString() + "("
                                                    + ds.child("overs").getValue().toString() + ")";
                                            Log.e("TAG!", s);

                                            match.setFirstTeamScore(s);

                                        } else {
                                            if (ds.getKey().equals(match.getTeamB())) {
                                                String s = ds.child("score").getValue(Long.class).toString() + "-"
                                                        + ds.child("wickets").getValue(Long.class).toString() + "("
                                                        + ds.child("overs").getValue().toString() + ")";
                                                match.setSecondTeamScore(s);

                                                Log.e("TAN!", s);
                                            }
                                        }
                                        _ongoing_temp.add(match);
                                        _ongoing_matchesList.postValue(_ongoing_temp);

                                    }

                                }

                                @Override
                                public void onCancelled(@android.support.annotation.NonNull DatabaseError databaseError) {

                                }
                            });

                        } else {
                            _upcoming_temp.add(match);
                            _upcoming_matchesList.postValue(_upcoming_temp);

                        }


                    }

                    @Override
                    public void onChildChanged(@android.support.annotation.NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        MatchDetails match = dataSnapshot.getValue(MatchDetails.class);
                        match.setMatchPudhId(dataSnapshot.getKey());

                    }

                    @Override
                    public void onChildRemoved(@android.support.annotation.NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@android.support.annotation.NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@android.support.annotation.NonNull DatabaseError databaseError) {

                    }
                });


    }


}
