package com.example.umair.supercricketliveline;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


import androidx.lifecycle.ViewModelProvider;

import com.example.umair.supercricketliveline.Adapters.SimpleFragmentPagerAdapter;
import com.example.umair.supercricketliveline.Adapters.homeViewPagerAdapter;
import com.example.umair.supercricketliveline.POJOClasses.HomeViewModel;

public class Home extends AppCompatActivity {
    HomeViewModel homeViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().setElevation(0);

        homeViewModel= new ViewModelProvider(this).get(HomeViewModel.class);

        ViewPager viewPager = findViewById(R.id.viewPagerHome);
        viewPager.setOffscreenPageLimit(3);



        homeViewPagerAdapter homeViewPagerAdapter = new homeViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(homeViewPagerAdapter);
        viewPager.setCurrentItem(0);

        final TabLayout tabLayout=(TabLayout) findViewById(R.id.homeTabLayout);
        tabLayout.setupWithViewPager(viewPager);
    }


    }

